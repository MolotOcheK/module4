from django.shortcuts import render
from django.http import HttpResponse

def ind(reqest):
    return HttpResponse('Домашка по 4 занятию')
# Create your views here.