from django.urls import path
from .views import ind

urlpatterns = [ 
    path('',ind)
]