from django.contrib import admin
from .models import Advertisement

class AdvertisementAdmin(admin.ModelAdmin):

    list_display = ["user", "title", "desc", "price", "auction", "create_date", "update_date", "resized_image"]
    actions = ["set_auction_as_true", "set_auction_as_false"]
    list_filter = ["title", "desc", "price", "auction"]
    fieldsets = (
        ("Общее", {
            "fields": ("title", "desc", "image"),
            "classes": ["collapse"],
        }),
        ("Финансы", {
            "fields": ("price", "auction"),
            "classes": ["collapse"]
        })
    )

    @admin.action(description="Убрать возможность торга")
    def set_auction_as_false(self, request, queryset):
        queryset.update(auction=False)

    @admin.action(description="Добавить возможность торга")
    def set_auction_as_true(self, request, queryset):
        queryset.update(auction=True)

admin.site.register(Advertisement, AdvertisementAdmin)