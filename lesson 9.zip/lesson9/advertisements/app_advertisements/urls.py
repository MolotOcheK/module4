from django.urls import path
from .views import ind, top_sellers, register, login, advertisement, advertisement_post, profile

urlpatterns = [ 
    path('',ind, name="index"),
    path('top-sellers/', top_sellers, name='a'),
    path('register/', register, name='reg'),
    path('login/', login, name='login'),
    path('profile/', profile, name='profile'),
    path('advertisement-post/', advertisement_post, name='ad_post'),
    path('advertisement/', advertisement, name='advertisement')
]